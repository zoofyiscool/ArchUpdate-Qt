/********************************************************************************
** Form generated from reading UI file 'notepad.ui'
**
** Created by: Qt User Interface Compiler version 5.15.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOTEPAD_H
#define UI_NOTEPAD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_notepad
{
public:
    QAction *actionNew_File;
    QAction *actionOpen_File;
    QAction *actionSave_File_As;
    QAction *actionPrint_File;
    QAction *actionExit;
    QAction *actionCopy_Text;
    QAction *actionPaste_Text;
    QAction *actionCut_Text;
    QAction *actionUndo_Action;
    QAction *actionRedo_Action;
    QAction *actionSave;
    QAction *actionAbout;
    QAction *actionMenubar;
    QAction *actionView_MB;
    QWidget *centralwidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QTextEdit *textEdit;
    QMenuBar *menubar;
    QMenu *menuFile;
    QMenu *menuEdit;
    QMenu *menuHelp;
    QMenu *menuView;
    QToolBar *toolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *notepad)
    {
        if (notepad->objectName().isEmpty())
            notepad->setObjectName(QString::fromUtf8("notepad"));
        notepad->setWindowModality(Qt::ApplicationModal);
        notepad->resize(800, 570);
        actionNew_File = new QAction(notepad);
        actionNew_File->setObjectName(QString::fromUtf8("actionNew_File"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/icons/documents.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNew_File->setIcon(icon);
        actionOpen_File = new QAction(notepad);
        actionOpen_File->setObjectName(QString::fromUtf8("actionOpen_File"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/images/icons/folder.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpen_File->setIcon(icon1);
        actionSave_File_As = new QAction(notepad);
        actionSave_File_As->setObjectName(QString::fromUtf8("actionSave_File_As"));
        actionSave_File_As->setEnabled(true);
        actionPrint_File = new QAction(notepad);
        actionPrint_File->setObjectName(QString::fromUtf8("actionPrint_File"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/images/icons/printer.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionPrint_File->setIcon(icon2);
        actionExit = new QAction(notepad);
        actionExit->setObjectName(QString::fromUtf8("actionExit"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/images/icons/exit.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionExit->setIcon(icon3);
        actionCopy_Text = new QAction(notepad);
        actionCopy_Text->setObjectName(QString::fromUtf8("actionCopy_Text"));
        actionPaste_Text = new QAction(notepad);
        actionPaste_Text->setObjectName(QString::fromUtf8("actionPaste_Text"));
        actionCut_Text = new QAction(notepad);
        actionCut_Text->setObjectName(QString::fromUtf8("actionCut_Text"));
        actionUndo_Action = new QAction(notepad);
        actionUndo_Action->setObjectName(QString::fromUtf8("actionUndo_Action"));
        actionRedo_Action = new QAction(notepad);
        actionRedo_Action->setObjectName(QString::fromUtf8("actionRedo_Action"));
        actionSave = new QAction(notepad);
        actionSave->setObjectName(QString::fromUtf8("actionSave"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/images/icons/diskette.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave->setIcon(icon4);
        actionAbout = new QAction(notepad);
        actionAbout->setObjectName(QString::fromUtf8("actionAbout"));
        actionMenubar = new QAction(notepad);
        actionMenubar->setObjectName(QString::fromUtf8("actionMenubar"));
        actionMenubar->setCheckable(false);
        actionMenubar->setChecked(false);
        actionView_MB = new QAction(notepad);
        actionView_MB->setObjectName(QString::fromUtf8("actionView_MB"));
        actionView_MB->setVisible(true);
        centralwidget = new QWidget(notepad);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(0, 0, 781, 551));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        textEdit = new QTextEdit(verticalLayoutWidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        verticalLayout->addWidget(textEdit);

        notepad->setCentralWidget(centralwidget);
        menubar = new QMenuBar(notepad);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 22));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuEdit = new QMenu(menubar);
        menuEdit->setObjectName(QString::fromUtf8("menuEdit"));
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        menuView = new QMenu(menubar);
        menuView->setObjectName(QString::fromUtf8("menuView"));
        notepad->setMenuBar(menubar);
        toolBar = new QToolBar(notepad);
        toolBar->setObjectName(QString::fromUtf8("toolBar"));
        notepad->addToolBar(Qt::LeftToolBarArea, toolBar);
        statusBar = new QStatusBar(notepad);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        notepad->setStatusBar(statusBar);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menuEdit->menuAction());
        menubar->addAction(menuView->menuAction());
        menubar->addAction(menuHelp->menuAction());
        menuFile->addAction(actionNew_File);
        menuFile->addAction(actionOpen_File);
        menuFile->addSeparator();
        menuFile->addAction(actionSave);
        menuFile->addAction(actionSave_File_As);
        menuFile->addAction(actionPrint_File);
        menuFile->addSeparator();
        menuFile->addAction(actionExit);
        menuEdit->addAction(actionCopy_Text);
        menuEdit->addAction(actionPaste_Text);
        menuEdit->addAction(actionCut_Text);
        menuEdit->addSeparator();
        menuEdit->addAction(actionUndo_Action);
        menuEdit->addAction(actionRedo_Action);
        menuHelp->addAction(actionAbout);
        menuView->addAction(actionMenubar);
        toolBar->addAction(actionNew_File);
        toolBar->addAction(actionOpen_File);
        toolBar->addAction(actionSave);
        toolBar->addAction(actionPrint_File);
        toolBar->addAction(actionView_MB);

        retranslateUi(notepad);

        QMetaObject::connectSlotsByName(notepad);
    } // setupUi

    void retranslateUi(QMainWindow *notepad)
    {
        notepad->setWindowTitle(QCoreApplication::translate("notepad", "notepad", nullptr));
        actionNew_File->setText(QCoreApplication::translate("notepad", "New File", nullptr));
#if QT_CONFIG(shortcut)
        actionNew_File->setShortcut(QCoreApplication::translate("notepad", "Ctrl+N", nullptr));
#endif // QT_CONFIG(shortcut)
        actionOpen_File->setText(QCoreApplication::translate("notepad", "Open File", nullptr));
#if QT_CONFIG(shortcut)
        actionOpen_File->setShortcut(QCoreApplication::translate("notepad", "Ctrl+O", nullptr));
#endif // QT_CONFIG(shortcut)
        actionSave_File_As->setText(QCoreApplication::translate("notepad", "Save File As", nullptr));
#if QT_CONFIG(shortcut)
        actionSave_File_As->setShortcut(QCoreApplication::translate("notepad", "Ctrl+Shift+S", nullptr));
#endif // QT_CONFIG(shortcut)
        actionPrint_File->setText(QCoreApplication::translate("notepad", "Print File", nullptr));
        actionExit->setText(QCoreApplication::translate("notepad", "Exit", nullptr));
        actionCopy_Text->setText(QCoreApplication::translate("notepad", "Copy Text", nullptr));
#if QT_CONFIG(shortcut)
        actionCopy_Text->setShortcut(QCoreApplication::translate("notepad", "Ctrl+C", nullptr));
#endif // QT_CONFIG(shortcut)
        actionPaste_Text->setText(QCoreApplication::translate("notepad", "Paste Text", nullptr));
#if QT_CONFIG(shortcut)
        actionPaste_Text->setShortcut(QCoreApplication::translate("notepad", "Ctrl+V", nullptr));
#endif // QT_CONFIG(shortcut)
        actionCut_Text->setText(QCoreApplication::translate("notepad", "Cut Text", nullptr));
#if QT_CONFIG(shortcut)
        actionCut_Text->setShortcut(QCoreApplication::translate("notepad", "Ctrl+X", nullptr));
#endif // QT_CONFIG(shortcut)
        actionUndo_Action->setText(QCoreApplication::translate("notepad", "Undo Action", nullptr));
#if QT_CONFIG(shortcut)
        actionUndo_Action->setShortcut(QCoreApplication::translate("notepad", "Ctrl+Z", nullptr));
#endif // QT_CONFIG(shortcut)
        actionRedo_Action->setText(QCoreApplication::translate("notepad", "Redo Action", nullptr));
#if QT_CONFIG(shortcut)
        actionRedo_Action->setShortcut(QCoreApplication::translate("notepad", "Ctrl+Q", nullptr));
#endif // QT_CONFIG(shortcut)
        actionSave->setText(QCoreApplication::translate("notepad", "Save", nullptr));
#if QT_CONFIG(shortcut)
        actionSave->setShortcut(QCoreApplication::translate("notepad", "Ctrl+S", nullptr));
#endif // QT_CONFIG(shortcut)
        actionAbout->setText(QCoreApplication::translate("notepad", "About", nullptr));
        actionMenubar->setText(QCoreApplication::translate("notepad", "Hide Menubar (CTRL + M to show)", nullptr));
        actionView_MB->setText(QString());
#if QT_CONFIG(shortcut)
        actionView_MB->setShortcut(QCoreApplication::translate("notepad", "Ctrl+M", nullptr));
#endif // QT_CONFIG(shortcut)
        menuFile->setTitle(QCoreApplication::translate("notepad", "File", nullptr));
        menuEdit->setTitle(QCoreApplication::translate("notepad", "Edit", nullptr));
        menuHelp->setTitle(QCoreApplication::translate("notepad", "Help", nullptr));
        menuView->setTitle(QCoreApplication::translate("notepad", "View", nullptr));
        toolBar->setWindowTitle(QCoreApplication::translate("notepad", "toolBar", nullptr));
    } // retranslateUi

};

namespace Ui {
    class notepad: public Ui_notepad {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOTEPAD_H
