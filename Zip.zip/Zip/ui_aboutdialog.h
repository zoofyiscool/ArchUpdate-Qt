/********************************************************************************
** Form generated from reading UI file 'aboutdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUTDIALOG_H
#define UI_ABOUTDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_aboutdialog
{
public:
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QDialog *aboutdialog)
    {
        if (aboutdialog->objectName().isEmpty())
            aboutdialog->setObjectName(QString::fromUtf8("aboutdialog"));
        aboutdialog->resize(291, 259);
        pushButton = new QPushButton(aboutdialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(90, 214, 101, 31));
        label = new QLabel(aboutdialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 0, 91, 61));
        QFont font;
        font.setPointSize(24);
        font.setUnderline(true);
        label->setFont(font);
        label_2 = new QLabel(aboutdialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(90, 50, 111, 31));
        QFont font1;
        font1.setPointSize(16);
        label_2->setFont(font1);
        label_3 = new QLabel(aboutdialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 120, 271, 31));
        QFont font2;
        font2.setPointSize(12);
        label_3->setFont(font2);

        retranslateUi(aboutdialog);

        QMetaObject::connectSlotsByName(aboutdialog);
    } // setupUi

    void retranslateUi(QDialog *aboutdialog)
    {
        aboutdialog->setWindowTitle(QCoreApplication::translate("aboutdialog", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("aboutdialog", "Okay", nullptr));
        label->setText(QCoreApplication::translate("aboutdialog", "About", nullptr));
        label_2->setText(QCoreApplication::translate("aboutdialog", "NotepadEx", nullptr));
        label_3->setText(QCoreApplication::translate("aboutdialog", "Developed by Ouxiez (aka zoofyiscool)", nullptr));
    } // retranslateUi

};

namespace Ui {
    class aboutdialog: public Ui_aboutdialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUTDIALOG_H
